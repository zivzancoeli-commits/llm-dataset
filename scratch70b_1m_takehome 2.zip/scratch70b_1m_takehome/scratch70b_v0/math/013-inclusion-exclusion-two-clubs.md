---
id: math-013
category: math
subcategory: combinatorics
difficulty: easy
source_model: fable-5
skills:
  - worked-solution
  - check-your-work
title: Inclusion-exclusion counting students in two clubs
approx_words: 580
---

Counting people who belong to overlapping groups is easy to get wrong in exactly one way: counting the overlap twice. Inclusion-exclusion is the systematic fix, and a two-club example shows both the formula and the picture behind it.

Problem: a class has 40 students. The chess club has 18 members from this class, and the debate club has 15. Seven students are in both clubs. How many students are in at least one club? And how many are in neither?

The naive move is 18 + 15 = 33 students "in a club." But walk through what that sum actually counts. Every student who is only in chess gets counted once. Every student only in debate gets counted once. And every student in both gets counted twice — once by the 18, once by the 15. The sum 33 isn't the number of students; it's the number of memberships. To convert memberships back into people, subtract one count for each double-counted person:

|chess or debate| = |chess| + |debate| - |chess and debate| = 18 + 15 - 7 = 26

So 26 students are in at least one club, and 40 - 26 = 14 are in neither.

Verify by partitioning, which is the tree-check of set problems. Break the class into four disjoint groups (disjoint means every student lands in exactly one):

- Both clubs: 7
- Chess only: 18 - 7 = 11
- Debate only: 15 - 7 = 8
- Neither: unknown, call it x

These must sum to the class: 7 + 11 + 8 + x = 40, so x = 14. And "at least one club" is 7 + 11 + 8 = 26. Both answers match the formula, and the partition additionally confirms internal consistency: chess-only came out positive (11 ≥ 0), which it must. If the problem had claimed 20 students in both clubs, chess-only would be 18 - 20 = -2, and the partition check would have exposed the data as impossible before you reported a nonsense answer. The formula alone happily produces numbers from impossible inputs; the partition doesn't.

The common mistake is the one we started with — adding the club sizes and stopping — but its mirror image is just as frequent: subtracting the overlap twice, or subtracting it when the question asks for "chess only." Keep the phrases straight: "in chess" (18) includes the dual members; "in chess only" (11) excludes them; "in at least one" (26) is the union; "in both" (7) is the intersection. Most errors in these problems are reading errors, not arithmetic errors, so translate each phrase into one of those four quantities before touching the numbers.

Why "inclusion-exclusion" as a name? Because the correction pattern continues for more sets, alternating signs. For three clubs: include the three single-club counts, exclude the three pairwise overlaps, then re-include the triple overlap (which the exclusions removed too many times):

|A or B or C| = |A| + |B| + |C| - |A and B| - |A and C| - |B and C| + |A and B and C|

You can trust this without memorizing it by auditing one student: someone in all three clubs is counted 3 - 3 + 1 = 1 time. Someone in exactly two is counted 2 - 1 = 1 time. Someone in exactly one is counted once. Everyone lands on exactly 1, which is what a correct count means. That per-person audit is the general verification technique: a counting formula is right precisely when every object contributes exactly one to the total.
